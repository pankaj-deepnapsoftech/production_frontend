declare module "*.csv" {
  const value: string;
  export default value;
}
